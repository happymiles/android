package com.example.hotel;

public interface MyInterface {
	public void set(int val);
	public void set();
}
