package com.example.hotel;

public interface ButtonIterface {
public void setData(int val);
}
