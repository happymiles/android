package com.example.hotel;

public interface ItemSelect {
public void assign(String id,String name,String price);
}
